const name = "Akshad Jaiswal"
var a = 10;
var b = 20;
var c = a + b;

console.log(name);
console.log(c);

// console.log(global)
// The globalThis global property contains the global this value, which is usually akin to the global object.

console.log(globalThis)
console.log(globalThis=== global)