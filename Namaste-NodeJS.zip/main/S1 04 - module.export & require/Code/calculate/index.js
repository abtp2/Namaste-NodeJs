const { calculateMultiply } = require("./multiply")
const { calculateSum } = require("./sum")

// #exporting modules
module.exports = { calculateSum, calculateMultiply };