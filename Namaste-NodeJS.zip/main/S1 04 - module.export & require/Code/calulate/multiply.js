function calculateMultiply(a, b) {
    const multiply = a * b;
    console.log(multiply)
}
module.exports = {
    calculateMultiply: calculateMultiply
}