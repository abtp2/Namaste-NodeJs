//require("/path");
// Alll the code of the module is wrapped inside the function(IIFE)
//IIFE - Imediately Invoked Function Expression

// (function () {
//     //All the code of the module is runs here

// })();
